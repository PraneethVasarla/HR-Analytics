# -*- coding: utf-8 -*-
"""
Created on Wed Jan 22 19:14:30 2020

@author: User
"""

https://www.berlinpackaging.com/hazmat-labels-signage/


1111111111111111
url='https://www.berlinpackaging.com/hazmat-labels-signage/'
tree = driver.get(url)
rest_details = dict()



#Scrapping product link
list_of = driver.find_elements_by_css_selector("div[class='itemWrapper hawk-itemWrapper']>a")
href_list = []
for i in range(0,len(list_of)):
    href = list_of[i].get_attribute('href')
    href_list.append(href)




#Scrapping product Name   
    Product_details = driver.find_elements_by_xpath('//div[1]//div[1]//div[1]//h3[1]')
    Product = [] 
    for it in Product_details:
        Product.append(it.text.strip())
    if Product:
        rest_details['Product_details']=Product
        list2 = [e for e in Product if e]
        test_list = list(filter(None,list2))
        
    caption_details = driver.find_elements_by_xpath('//div[contains(@class,"hawk-header-2")]')
    captions = []
    for it in caption_details:
        captions.append(it.text.strip())
    if captions:
        rest_details['caption_details']=captions
    else:
        rest_details['caption_details']='N/A'    



        
for i in range(0,len(href_list)):
    print(href_list[i])
    print(Product[i])
    print(captions[i])
    
    list2 = []
    list2.append(href_list[i])
    list2.append(Product[i])
    list2.append(captions[i])
    with open('hazmat-labels-signage.csv', 'a', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(list2)
        print(list2)
   