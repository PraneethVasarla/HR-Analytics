# -*- coding: utf-8 -*-
"""
Created on Thu Jan 23 18:50:43 2020

@author: User
"""

333333333333333333333333


import xlwt 
from xlwt import Workbook
import pandas as pd

wb = Workbook()


pages = pd.read_csv('C:/Users/User/Anaconda3/Lib/site-packages/selenium/webdriver/labels35.csv')

ref = []
pages.columns = ['href', 'product_name' , 'option']



#x = []
sheet1 = wb.add_sheet('Sheet 20', cell_overwrite_ok=True)
sheet1.write(0,0, 'HREF')
sheet1.write(0,1, 'OP1')
sheet1.write(0,2, 'OP2')
sheet1.write(0,3, 'OP3')
sheet1.write(0,4, 'OP4')
sheet1.write(0,5, 'OP5')

#wb.save('xlwt examplee3.xls')            


i=1
for link in pages['href']:
    j=0
    driver.get(link)
    print(link)
    #print(i,j)
    sheet1.write(i,j,link)
    j=j+1
    #print(i,j)
    x = driver.find_elements(By.XPATH, "//div[@id='custom-input-fields']//div[@class='form-field-customField']")
    n = []
    for option in x:
        ''''str=''
        str+=option'''
    
        #sheet1.write(i,j,option)
        d=option.get_attribute("data-product-attribute")
        n.append(d)
        print(n)
    k=2
    l=1
    
    
    for des1 in n:
        print(des1)
        print('----------')
        if des1=='Selection_Description':
            print(i,j,des1)
            sheet1.write(i,1,des1)
            j=j+1
        elif des1=='Selection_Diameter':
            print(i,j,des1)
            sheet1.write(i,2,des1)
            j=j+1
       
        elif des1=='Selection_Length':
           
            print(i,j,des1)
            sheet1.write(i,3,des1)
            j=j+1
       
        elif des1=='Selection_Width':
            
            print(i,j,des1)
            sheet1.write(i,4,des1)
            j=j+1
            
        else:
            print(i,j,des1)
            sheet1.write(i,j,' ')
        
    i=i+1 
    k=k+1      
            
            
wb.save('xlwt labels37.xls')      