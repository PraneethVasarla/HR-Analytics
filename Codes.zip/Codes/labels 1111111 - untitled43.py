# -*- coding: utf-8 -*-
"""
Created on Thu Jan 23 11:10:06 2020

@author: User
"""
11111111
https://www.berlinpackaging.com/labels/


from selenium import webdriver
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import NoSuchElementException
import csv  
import time
from time import sleep



import csv      

options = webdriver.ChromeOptions()
options.add_argument('--ignore-certificate-errors')
options.add_argument('--incognito')
options.add_argument('--headless')
driver = webdriver.Chrome(executable_path='C:/chromedriver_win32/chromedriver.exe', options=options)

driver.get("https://www.berlinpackaging.com/5-gal-pail-strainers/")
wait= WebDriverWait(driver, 30)
##cookie Crasher
wait.until(lambda driver: driver.find_element_by_xpath("//a[@class='cc-btn cc-dismiss']"))
driver.find_element(By.XPATH, "//a[@class='cc-btn cc-dismiss']").click()

url='https://www.berlinpackaging.com/labels/'
from selenium.webdriver.support.wait import WebDriverWait
driver.get(url)
rest_details = dict()





#Scrapping product link
list_of = driver.find_elements_by_xpath("//div[@class='itemWrapper hawk-itemWrapper ']/a")
href_list = []
for i in range(0,len(list_of)):
    href = list_of[i].get_attribute('href')
    href_list.append(href)
print(href_list)



#Scrapping product Name   
    Product_details = driver.find_elements_by_xpath('//div[1]//div[1]//div[1]//h3[1]')
    Product = [] 
    for it in Product_details:
        Product.append(it.text.strip())
    if Product:
        rest_details['Product_details']=Product
        list2 = [e for e in Product if e]
        test_list = list(filter(None,list2))
        
    caption_details = driver.find_elements_by_xpath('//div[contains(@class,"hawk-header-2")]')
    captions = []
    for it in caption_details:
        captions.append(it.text.strip())
    if captions:
        rest_details['caption_details']=captions
    else:
        rest_details['caption_details']='N/A'    



        
for i in range(0,len(href_list)):
    print(href_list[i])
    print(Product[i])
    print(captions[i])
    
    list2 = []
    list2.append(href_list[i])
    list2.append(Product[i])
    list2.append(captions[i])
    with open('labels35.csv', 'a', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(list2)
        print(list2)
