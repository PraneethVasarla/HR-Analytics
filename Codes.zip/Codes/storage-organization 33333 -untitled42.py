# -*- coding: utf-8 -*-
"""
Created on Wed Jan 22 21:16:36 2020

@author: User
"""

33333333333333333333333333333333333333333
https://www.berlinpackaging.com/storage-organization/


import xlwt 
from xlwt import Workbook

wb = Workbook() 


pages = pd.read_csv('C:/Users/User/Anaconda3/Lib/site-packages/selenium/webdriver/shipping-boxes.csv')


ref = []
pages.columns = ['href', 'product_name' , 'option']
#x = []
sheet1 = wb.add_sheet('Sheet 1', cell_overwrite_ok=True)
sheet1.write(0,0, 'HREF')
sheet1.write(0,1, 'OP1')
sheet1.write(0,2, 'OP2')
sheet1.write(0,3, 'OP3')
sheet1.write(0,4, 'OP4')










import xlwt 
from xlwt import Workbook

wb = Workbook()





pages = pd.read_csv('C:/Users/User/Anaconda3/Lib/site-packages/selenium/webdriver/storage-organization35.csv')

ref = []
pages.columns = ['href', 'product_name' , 'option']



#x = []
sheet1 = wb.add_sheet('Sheet 17', cell_overwrite_ok=True)
sheet1.write(0,0, 'HREF')
sheet1.write(0,1, 'OP1')
sheet1.write(0,2, 'OP2')
sheet1.write(0,3, 'OP3')
sheet1.write(0,4, 'OP4')
sheet1.write(0,5, 'OP5')
sheet1.write(0,6, 'OP6')
sheet1.write(0,7, 'OP7')
sheet1.write(0,8, 'OP8')
sheet1.write(0,9, 'OP9')
#wb.save('xlwt examplee3.xls')            


i=1
for link in pages['href']:
    j=0
    driver.get(link)
    #print(i,j)
    sheet1.write(i,j,link)
    j=j+1
    #print(i,j)
    x = driver.find_elements(By.XPATH, "//div[@id='custom-input-fields']//div[@class='form-field-customField']")
    n = []
    for option in x:
        ''''str=''
        str+=option'''
    
        #sheet1.write(i,j,option)
        d=option.get_attribute("data-product-attribute")
        n.append(d)
        print(n)
    k=2
    l=1
    
    
    for des1 in n:
        print(des1)
        print('----------')
        if des1=='Selection_Case Qty':
            print(i,j,des1)
            sheet1.write(i,1,des1)
            j=j+1
        elif des1=='Selection_Color':
            print(i,j,des1)
            sheet1.write(i,2,des1)
            j=j+1
       
        elif des1=='Selection_Depth':
           
            print(i,j,des1)
            sheet1.write(i,3,des1)
            j=j+1
       
        elif des1=='Selection_Description':
            
            print(i,j,des1)
            sheet1.write(i,4,des1)
            j=j+1
        
        elif des1=='Selection_Height':
            print(i,j,des1)
            sheet1.write(i,5,des1)
            j=j+1
        elif des1=='Selection_Length':
            print(i,j,des1)
            sheet1.write(i,6,des1)
            j=j+1    
                    
        elif des1=='Selection_Max Load':
            print(i,j,des1)
            sheet1.write(i,7,des1)
            j=j+1
        elif des1=='Selection_Size':
            print(i,j,des1)
            sheet1.write(i,8,des1)
            j=j+1    
        elif des1=='Selection_Width':
            print(i,j,des1)
            sheet1.write(i,9,des1)
            j=j+1    
        else:
            print(i,j,des1)
            sheet1.write(i,j,' ')
        
    i=i+1 
    k=k+1      
            
            
wb.save('xlwt storage-organization36.xls')      