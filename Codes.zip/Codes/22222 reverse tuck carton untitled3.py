# -*- coding: utf-8 -*-
"""
Created on Wed Jan 22 16:26:00 2020

@author: User
"""

from selenium import webdriver

import pandas as pd
import csv

options = webdriver.ChromeOptions()
options.add_argument('--ignore-certificate-errors')
options.add_argument('--incognito')
options.add_argument('--headless')
driver = webdriver.Chrome(executable_path='C:/chromedriver_win32/chromedriver.exe', options=options)



pages.columns = ['href', 'product_name' , 'option']
for link in pages['href']:
    driver.get(link)
    x = driver.find_elementpages = pd.read_csv('C:/Users/User/Anaconda3/Lib/site-packages/selenium/webdriver/reverse-tuck-carton.csv')

s(By.XPATH, "//div[@id='custom-input-fields']//div[@class='form-field-customField']")
    
    for option in x:
        n=[]
        n.append(option.get_attribute("data-product-attribute") )
       
        
        with open("Combination_reverse-tuck-carton.csv", "a", newline='') as f:
            writer = csv.writer(f)
            writer.writerow(n)
            print("----end----")
