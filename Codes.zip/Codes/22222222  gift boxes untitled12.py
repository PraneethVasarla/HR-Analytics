# -*- coding: utf-8 -*-
"""
Created on Wed Jan 22 17:09:41 2020

@author: User
"""


pages = pd.read_csv('C:/Users/User/Anaconda3/Lib/site-packages/selenium/webdriver/gift-boxes.csv')


pages.columns = ['href', 'product_name' , 'option']
for link in pages['href']:
    driver.get(link)
    x = driver.find_elements(By.XPATH, "//div[@id='custom-input-fields']//div[@class='form-field-customField']")
    
    for option in x:
        n=[]
        n.append(option.get_attribute("data-product-attribute") )
       
        
        with open("Combination_gift-boxes.csv", "a", newline='') as f:
            writer = csv.writer(f)
            writer.writerow(n)
            print("----end----")
