# -*- coding: utf-8 -*-
"""
Created on Wed Jan 22 15:38:32 2020

@author: User
"""
2222222222222222222
import pytest
import time
import csv
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.firefox.options import Options
import bs4 as bs
import pandas as pd
from datetime import datetime

options = webdriver.ChromeOptions()
options.add_argument('--ignore-certificate-errors')
options.add_argument('--incognito')
options.add_argument('--headless')
driver = webdriver.Chrome(executable_path='C:/chromedriver_win32/chromedriver.exe', options=options)


pages = pd.read_csv('C:/Users/User/Anaconda3/Lib/site-packages/selenium/webdriver/shipping-boxes.csv')


pages.columns = ['href', 'product_name' , 'option']
for link in pages['href']:
    driver.get(link)
    x = driver.find_elements(By.XPATH, "//div[@id='custom-input-fields']//div[@class='form-field-customField']")
    
    for option in x:
        n=[]
        n.append(option.get_attribute("data-product-attribute") )
       
        
        with open("Combination_shipping-boxes1.csv", "a", newline='') as f:
            writer = csv.writer(f)
            writer.writerow(n)
            print("----end----")
